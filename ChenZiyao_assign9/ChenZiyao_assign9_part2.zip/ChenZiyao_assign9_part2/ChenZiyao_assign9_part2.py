def valid_username(s):
    flag = True
    if len(s) < 5:
        flag = False
    elif not s.isalnum():
        flag = False
    elif s[0].isdigit():
        flag = False
    return flag

def valid_password(s):
    flag = True
    if len(s) < 5:
        flag = False
    elif not s.isalnum():
        flag = False
    elif s.islower():
        flag = False
    elif s.isupper():
        flag = False
    elif s.isalpha():
        flag = False
    elif s.isdigit():
        flag = False
    return flag

def username_exists(s):
    file = open('user_info.txt','r')
    data = file.read()
    split_data = data.split("\n")
    split_data.pop(-1)
    flag = False
    for i in range(len(split_data)):
        ssplit_data = split_data[i].split(",")
        for ii in range(len(ssplit_data)):
            if s == ssplit_data[0]:
                flag = True
    file.close()
    return flag

def check_password(s1,s2):
    file = open('user_info.txt','r')
    data = file.read()
    split_data = data.split("\n")
    split_data.pop(-1)
    for i in range(len(split_data)):
        flag1 = False
        flag2 = False
        ssplit_data = split_data[i].split(",")
        if ssplit_data[0] == s1:
            flag1 = True
        if ssplit_data[-1] == s2:
            flag2 = True
        if flag1 and flag2:
            return True
    file.close()
    return False

def add_user(s1,s2):
    if not username_exists(s1):
        if valid_username(s1):
            if valid_password(s2):
                file = open('user_info.txt','a')
                file.write(s1+","+s2+"\n")
                file.close()
                send_message("admin",s1,"Welcome to your account!")
                return True
    return False
        
def send_message(s1,s2,s3):
    file = open('messages/'+s2+'.txt','a')
    import datetime
    d = datetime.datetime.now()
    month = str(d.month)
    day = str(d.day)
    year = str(d.year)
    hour = str(d.hour)
    minute = str(d.minute)
    second = str(d.second)
    file.write(s1+"|"+month+"/"+day+"/"+year+" "+hour+":"+minute+":"+second+"|"+s3+"\n")
    file.close()

def print_messages(s):
    file = open('messages/'+s+'.txt','r')
    data = file.read()
    if data == '\n':
        print("No messages in your inbox")
        print()
    else:
        split_data = data.split("\n")
        split_data.pop(-1)
        for i in range(len(split_data)):
            ssplit_data = split_data[i].split("|")
            print("Message #",i+1," received from "+ssplit_data[0],sep='')
            print("Time:",ssplit_data[1])
            print(ssplit_data[2])
            print()

def delete_messages(s):
    file = open('messages/'+s+'.txt','w')
    file.write("\n")
    file.close

while True:
    choice = input("(l)ogin, (r)egister or (q)uit: ")
    print()
    if choice == 'q':
        print("Goodbye!")
        break
    if choice == 'r':
        print("Register for an account")
        username = input("Username (case sensitive): ")
        password = input("Password (case sensitive): ")
        if not valid_username(username):
            print("Username is invalid, registration cancelled")
            print()
            continue
        if username_exists(username):
            print("Duplicate username, registration cancelled")
            print()
            continue
        if not valid_password(password):
            print("Password is invalid, registration cancelled")
            print()
            continue
        add_user(username,password)
        print("Registration successful!")
        print()
        continue
    if choice == 'l':
        print("Log In")
        Username = input("Username (case sensitive): ")
        Password = input("Password (case sensitive): ")
        if check_password(Username,Password):
            while True:
                print("You have been logged in successfully as",Username)
                choicee = input("(r)ead messages, (s)end a message, (d)elete messages or (l)ogout: ")
                if choicee == 'r':
                    print()
                    print_messages(Username)
                    continue
                if choicee == 's':
                    recipient = input("Username of recipient: ")
                    if username_exists(recipient):
                        message = input("Type your message: ")
                        send_message(Username,recipient,message)
                        print("Message sent!")
                        print()
                    else:
                        print("Unknown recipient")
                        print()
                    continue
                if choicee == 'd':
                    delete_messages(Username)
                    print("Your messages have been deleted")
                    print()
                if choicee == 'l':
                    print("Logging out as username",Username)
                    print()
                    break
            
